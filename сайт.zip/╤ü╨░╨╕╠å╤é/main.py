from flask import Flask, render_template, request
import os
app = Flask(__name__,template_folder=os.getcwd())
print(os.getcwd())

@app.route('/')
def index():
  return render_template('index.html')

@app.route('/landing')
def landing():
  return render_template('landing.html')

@app.route('/main', methods=['GET', 'POST'])
def main():
  return render_template('main.html')
@app.route('/authorization', methods=['GET', 'POST'])
def authorization():
  login = request.args.get('login')
  password = request.args.get('password')
  print(login,password)
  # return render_template('landing.html')
  return 'Логин: '+login+'  Пароль:'+password
if __name__ == '__main__':
  app.run(host='0.0.0.0', debug=False)