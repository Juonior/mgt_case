let login_open;
let reg_open;
let arg;
let password;
let type;
let url_api;
reg_open = 0;
login_open = 0;

url_api = '192.168.2.60:5000'
payload = {
    "email": "jgugonior",
    "name": "juonior",
    "surname": "string",
    "patronymic": "string",
    "phone_number": "juggonior",
    "password": "123",
    "passport_data": "string"
  }
// alert('gg')
// if (response.ok) { // если HTTP-статус в диапазоне 200-299
//     // получаем тело ответа (см. про этот метод ниже)
//     let json = await response.json();
//     alert(json)
//     } else {
//     alert("Ошибка HTTP: " + response.status);
//     }
// alert('gggg')
function login_func() {
    arg = document.getElementById('login_phone').value;
    password = document.getElementById('login_password').value
    type = ''
    if (arg.includes('@')){
        type = 'email'
    } else {
        type = 'phone_number'
    }
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'http://'+url_api+'/auth/'+type+'/'+arg+'/'+password);
    xhr.send();
    xhr.onload = function(e) {
        // alert(this.response['email'])
        console.log(this.status)
        if (this.status == 200) {
            console.log('response', this.response); // JSON response  
            document.cookie = "userid="+JSON.parse(this.response)['id']; // обновляем только куки с именем 'user'
            window.location.replace("/main");
            // document.getElementById('login_phone').method="post";
        } else {
            document.getElementById('error_text').style.display = "block";
        }
    };
}
    // alert(login+' '+password);
    // document.getElementById('login_href').action = '/authorization?login="'+login+'"&password="'+password+'"';
function showDiv() {
    if (login_open== 1){
        show_login();
    }
    if (reg_open==1){
        show_register();
    }
    document.getElementById('shadow').classList.toggle("block");
    setTimeout(() => { document.getElementById('shadow').classList.toggle("show"); }, 200);

    document.getElementById('auth').classList.toggle("block_auth");
    setTimeout(() => { document.getElementById('auth').classList.toggle("show_auth"); }, 200);
 }

function show_login(){
    if (login_open== 0){
        login_open = 1;

    } else {
        login_open = 0;
    }
    document.getElementById('register').classList.toggle("hide");
    document.getElementById('login').classList.toggle("hide");
    setTimeout(() => { document.getElementById('login').classList.toggle("none"); }, 200);
    setTimeout(() => { document.getElementById('register').classList.toggle("none"); }, 200);

    document.getElementById('auth_div').classList.toggle("auth_div_block");
    setTimeout(() => { document.getElementById('auth_div').classList.toggle("auth_div_show"); }, 200);

}

function show_register(){
    if (reg_open== 0){
        reg_open = 1;

    } else {
        reg_open = 0;
    }
    document.getElementById('register').classList.toggle("hide");
    document.getElementById('login').classList.toggle("hide");
    setTimeout(() => { document.getElementById('login').classList.toggle("none"); }, 200);
    setTimeout(() => { document.getElementById('register').classList.toggle("none"); }, 200);

    document.getElementById('register_div').classList.toggle("register_div_block");
    setTimeout(() => { document.getElementById('register_div').classList.toggle("register_div_show"); }, 200);
}
function register_user(){
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'http://'+url_api+'/users');
    xhr.setRequestHeader("Content-Type", "application/json");
    payload = {
        "email": document.getElementById('reg_email').value,
        "name": document.getElementById('reg_name').value,
        "surname": document.getElementById('reg_surname').value,
        "patronymic": document.getElementById('reg_patronymic').value,
        "phone_number": document.getElementById('reg_phone').value,
        "password": document.getElementById('reg_password').value,
        'routes': {},
        "passport_data": document.getElementById('reg_pass_num').value+';'+document.getElementById('reg_pass_given').value+';'+document.getElementById('reg_pass_date').value+';'+document.getElementById('reg_pass_code').value,
    }
    xhr.send(JSON.stringify(payload));
    xhr.onload = function(e) {
        // alert(this.response['email'])
        console.log(this.status)
    //   if (this.status == 200) {
        console.log('response', this.response); // JSON response  
    //   }
    };
    console.log(payload)
}