let k = 0;
let url_api;
let bus_info;
let user_info;
url_api = '192.168.2.60:5000';
bus_info = []
user_info = []


function getCookie(name) {
    let matches = document.cookie.match(new RegExp(
      "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
    ));
    return matches ? decodeURIComponent(matches[1]) : undefined;
  }


const xhr = new XMLHttpRequest();
xhr.open('GET', 'http://'+url_api+'/get_all_routes/');
xhr.send();
xhr.onload = function(e) {
    // alert(this.response['email'])
    console.log(this.status)
    if (this.status == 200) {
        console.log('response', JSON.parse(this.response)); // JSON response  
        bus_info = JSON.parse(this.response)
        // window.location.replace("/main");
        // document.getElementById('login_phone').method="post";
    }
};


const gg = new XMLHttpRequest();
gg.open('GET', 'http://'+url_api+'/get_user_by_user_id/'+getCookie('userid'));
gg.send();
gg.onload = function(e) {
    // alert(this.response['email'])
    console.log(this.status)
    if (this.status == 200) {
        console.log('response', JSON.parse(this.response)); // JSON response  
        user_info = JSON.parse(this.response)

        for (var key in user_info['routes']){
            k += 1
            document.getElementById('routes').innerHTML += '<div class="horizontal"><h1 class="choose_bus_text">'+k+'. Выберите номер автобуса</h1><h1 class="a_text">Точка А</h1><h1 class="b_text">Точка Б</h1></div><div class="horizontal"><select onchange="change_stations('+k+')" id="select_bus'+k+'" class="choose_bus"></select><select id="a'+k+'" class="a_bus"></select><select id="b'+k+'" class="b_bus"></select></div>'
            select = document.getElementById('select_bus'+k);
            for (var z = 0; z<bus_info.length; z++){
                var opt = document.createElement('option');
                opt.value = bus_info[z]['route_name'];
                opt.innerHTML =  bus_info[z]['route_name'];
                select.appendChild(opt);
                for (var l = 0; l<bus_info[z]['stations'].length; l++){
                    a = document.getElementById('a'+k);
                    var opt = document.createElement('option');
                    opt.innerHTML =  bus_info[z]['stations'][l];
                    a.appendChild(opt);
    
                    b = document.getElementById('b'+k);
                    var opt = document.createElement('option');
                    opt.innerHTML =  bus_info[z]['stations'][l];
                    b.appendChild(opt);
                }
        }
        // console.log(key, user_info['routes'][key][0]);
        document.getElementById('select_bus'+k).value = key;
        console.log(key,'select_bus'+k, document.getElementById('select_bus'+k).value)
        document.getElementById('a'+k).value = user_info['routes'][key][0]
        document.getElementById('b'+k).value = user_info['routes'][key][user_info['routes'][key].length-1]
        // document.getElementById('select_bus1').value = 15.ss;
        }
        // window.location.replace("/main");
        // document.getElementById('login_phone').method="post";
    }
};
function show_create_orders(){
    document.getElementById('create-order').style.display = 'block';
    document.getElementById('market_order').style.display = 'None'
    document.getElementById('market_orders_text').style.color = '#9699A3';
    document.getElementById('create_order_text').style.color = '#2D67AD';
    // alert('gg')
}


function show_orders(){
    document.getElementById('create-order').style.display = 'None';
    document.getElementById('market_order').style.display = 'block'
    document.getElementById('market_orders_text').style.color = '#2D67AD';
    document.getElementById('create_order_text').style.color = '#9699A3';
    // console.log(user_info['routes'].length)
    // for (var i = 0; i<=user_info['routes'].length; i++){
    //     console.log(i);
    // }
    // alert('gg')

    // for (var i = 1; i<=k; i++){
    //     select = document.getElementById('select_bus'+k);
    //     var opt = document.createElement('option');
    //     for (var z = 0; z<bus_info.length; z++){
    //         opt.value = bus_info[z]['route_name'];
    //         opt.innerHTML =  bus_info[z]['route_name'];
    //         select.appendChild(opt);
            // for (var l = 0; l<bus_info[z]['stations'].length; l++){
            //     a = document.getElementById('a'+k);
            //     var opt = document.createElement('option');
            //     opt.innerHTML =  bus_info[z]['stations'][l];
            //     a.appendChild(opt);

            //     b = document.getElementById('b'+k);
            //     var opt = document.createElement('option');
            //     opt.innerHTML =  bus_info[z]['stations'][l];
            //     b.appendChild(opt);
            // }
    //     }
    // }
}
function add_route(){
    k += 1;
    document.getElementById('routes').innerHTML += '<div class="horizontal"><h1 class="choose_bus_text">'+k+'. Выберите номер автобуса</h1><h1 class="a_text">Точка А</h1><h1 class="b_text">Точка Б</h1></div><div class="horizontal"><select onchange="change_stations('+k+')" id="select_bus'+k+'" class="choose_bus"></select><select id="a'+k+'" class="a_bus"></select><select id="b'+k+'" class="b_bus"></select></div>'
    select = document.getElementById('select_bus'+k);
    var opt = document.createElement('option');
    console.log(k)
    for (var z = 0; z<bus_info.length; z++){
        opt.value = bus_info[z]['route_name'];
        opt.innerHTML =  bus_info[z]['route_name'];
        select.appendChild(opt);
        for (var l = 0; l<bus_info[z]['stations'].length; l++){
            a = document.getElementById('a'+k);
            var opt = document.createElement('option');
            opt.innerHTML =  bus_info[z]['stations'][l];
            a.appendChild(opt);

            b = document.getElementById('b'+k);
            var opt = document.createElement('option');
            opt.innerHTML =  bus_info[z]['stations'][l];
            b.appendChild(opt);
        }
    }
}

function removeOptions(selectElement) {
    var i, L = selectElement.options.length - 1;
    for(i = L; i >= 0; i--) {
       selectElement.remove(i);
    }
 }
function change_stations(label_num){
    bus_num = document.getElementById('select_bus'+label_num).value;
    alert(bus_num);
    for (var z = 0; z<bus_info.length; z++){
        if (bus_info[z]['route_name'] == bus_num){
            a = document.getElementById('a'+label_num);
            removeOptions(a);
            b = document.getElementById('b'+label_num);
            removeOptions(b);
            for (var l = 0; l<bus_info[z]['stations'].length; l++){
                
                var opt = document.createElement('option');
                opt.innerHTML =  bus_info[z]['stations'][l];
                a.appendChild(opt);

                var opt = document.createElement('option');
                opt.innerHTML =  bus_info[z]['stations'][l];
                b.appendChild(opt);
            }
        }
    }
}